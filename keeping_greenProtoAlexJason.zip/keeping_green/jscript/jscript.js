<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

$(document).ready(function() {
  $('form').submit(function(event) {
    event.preventDefault();
    var email = $('#email').val();
    alert('Thank you for subscribing with ' + email);
  });

  $('.card').hover(function() {
    $(this).toggleClass('shadow-lg');
  });

  $('button').click(function() {
    $('form').toggleClass('animate__animated animate__bounceIn');
  });
});
